package br.com.posfiap.restmanager.application.mapper;

import br.com.posfiap.restmanager.domain.model.Usuario;
import br.com.posfiap.restmanager.infrastructure.persistence.jpa.entity.UsuarioEntity;
import br.com.posfiap.restmanager.application.dto.UsuarioCreateDto;
import br.com.posfiap.restmanager.application.dto.UsuarioResponseDto;
import br.com.posfiap.restmanager.application.dto.UsuarioUpdateDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.time.LocalDateTime;

@Mapper(componentModel = "spring", imports = LocalDateTime.class)
public interface UsuarioMapper {

    // DTO → Model
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "dataUltimaAlteracao", ignore = true)
    Usuario mapToUsuario(UsuarioCreateDto usuarioCreateDto);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "senha", ignore = true)
    @Mapping(target = "dataUltimaAlteracao", ignore = true)
    Usuario mapToUsuario(UsuarioUpdateDto usuarioUpdateDto);

    // Model → DTO
    UsuarioResponseDto mapToUsuarioResponseDto(Usuario usuario);

    // Model → Entity
    @Mapping(target = "dataUltimaAlteracao", expression = "java(LocalDateTime.now())")
    UsuarioEntity mapToUsuarioEntity(Usuario usuario);

    // Entity → Model
    Usuario mapToUsuario(UsuarioEntity usuarioEntity);
}
