package br.com.posfiap.restmanager.domain.enums;

public enum TipoUsuario {

    CLIENTE,
    PROPRIETARIO
}