package br.com.posfiap.restmanager.domain.exception;

public class BusinessException extends AbstractRestException {
    public BusinessException(String msg) {
        super(msg);
    }
}
